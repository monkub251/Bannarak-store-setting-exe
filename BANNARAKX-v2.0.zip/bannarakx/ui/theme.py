"""Monochrome theme tokens + global stylesheet."""

BG = "#070708"
BG_PANEL = "#0B0B0D"
LINE = "#1E1E22"
LINE_SOFT = "#141417"
TEXT = "#EDEDED"
TEXT_DIM = "#8A8A90"
TEXT_FAINT = "#4E4E55"
ACCENT = "#FFFFFF"

FONT_UI = "Rajdhani, Bahnschrift, Segoe UI, Arial"
FONT_TH = "Noto Sans Thai, Leelawadee UI, Segoe UI, Tahoma"
FONT_MONO = "JetBrains Mono, Consolas, Cascadia Mono, monospace"

QSS = f"""
* {{
    font-family: "{FONT_UI}";
    color: {TEXT};
}}

QWidget#root {{
    background: {BG};
}}

QLabel[role="brand"] {{
    font-size: 21px;
    font-weight: 700;
    letter-spacing: 5px;
    color: {TEXT};
}}
QLabel[role="brandsub"] {{
    font-size: 9px;
    letter-spacing: 3px;
    color: {TEXT_FAINT};
}}

QPushButton[role="nav"] {{
    background: transparent;
    border: none;
    padding: 6px 2px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 2.5px;
    color: {TEXT_FAINT};
}}
QPushButton[role="nav"]:hover {{ color: {TEXT_DIM}; }}
QPushButton[role="nav"][active="true"] {{
    color: {TEXT};
    border-bottom: 2px solid {ACCENT};
}}

QPushButton[role="win"], QPushButton[role="close"] {{
    background: transparent;
    border: none;
    outline: none;
    color: {TEXT_DIM};
    font-size: 15px;
    padding: 0;
}}
QPushButton[role="win"]:hover, QPushButton[role="close"]:hover {{
    background: rgba(255,255,255,0.07);
    color: {TEXT};
}}
QPushButton[role="win"]:pressed, QPushButton[role="close"]:pressed {{
    background: rgba(255,255,255,0.12);
}}
QPushButton[role="close"]:hover {{
    background: rgba(255,90,90,0.16);
    color: #FF5A5A;
}}

QLabel[role="sectionlabel"] {{
    font-size: 10px;
    letter-spacing: 3.5px;
    color: {TEXT_FAINT};
}}

QLabel[role="blurb"] {{
    font-family: "{FONT_TH}";
    font-size: 13px;
    color: {TEXT_DIM};
    line-height: 160%;
}}
QLabel[role="bullet"] {{
    font-family: "{FONT_TH}";
    font-size: 12px;
    color: {TEXT_DIM};
}}

QLabel[role="status"] {{
    font-size: 10px;
    letter-spacing: 2.5px;
    color: {TEXT_FAINT};
}}
QLabel[role="statusval"] {{
    font-size: 10px;
    letter-spacing: 2.5px;
    color: {TEXT};
}}

QPlainTextEdit {{
    background: {BG_PANEL};
    border: 1px solid {LINE};
    font-family: "{FONT_MONO}";
    font-size: 11px;
    color: {TEXT_DIM};
    selection-background-color: #2A2A30;
}}

QProgressBar {{
    background: {LINE_SOFT};
    border: none;
    height: 2px;
    text-align: center;
}}
QProgressBar::chunk {{ background: {ACCENT}; }}

QScrollBar:vertical {{
    background: transparent; width: 6px; margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {LINE}; border-radius: 3px; min-height: 30px;
}}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}

QDialog {{ background: {BG_PANEL}; }}
QCheckBox {{ font-size: 12px; color: {TEXT_DIM}; }}
"""
