"""Profile card, clipped-corner action button, pulse waveform, title bar."""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import QLabel, QPushButton, QWidget

from .theme import ACCENT, LINE, TEXT, TEXT_DIM, TEXT_FAINT


class ProfileCard(QWidget):
    clicked = Signal(str)

    def __init__(self, key: str, data: dict, parent=None):
        super().__init__(parent)
        self.key = key
        self.data = data
        self.selected = False
        self.setFixedHeight(76)
        self.setCursor(Qt.PointingHandCursor)
        self.has_wave = key == "PULSE"

    def set_selected(self, on: bool):
        self.selected = on
        self.update()

    def mousePressEvent(self, _e):
        self.clicked.emit(self.key)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        h = self.height()

        if self.selected:
            p.fillRect(QRectF(0, 0, 3, h), QColor(ACCENT))
            name_col = QColor(TEXT)
            sub_col = QColor(TEXT_DIM)
            idx_col = QColor(TEXT_DIM)
        else:
            p.fillRect(QRectF(0, 0, 3, h), QColor("#26262B"))
            name_col = QColor("#5C5C63")
            sub_col = QColor(TEXT_FAINT)
            idx_col = QColor(TEXT_FAINT)

        f = QFont("Rajdhani", 21)
        f.setWeight(QFont.Bold)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 1.5)
        p.setFont(f)
        p.setPen(name_col)
        p.drawText(QPointF(20, 34), self.data["name"])
        name_right = 20 + p.fontMetrics().horizontalAdvance(self.data["name"])

        if self.has_wave:
            self._draw_wave(p, name_right + 26, self.width() - 52, 29)

        f2 = QFont("Rajdhani", 8)
        f2.setLetterSpacing(QFont.AbsoluteSpacing, 3.0)
        p.setFont(f2)
        p.setPen(sub_col)
        p.drawText(QPointF(21, 52), self.data["sub"])

        p.setFont(f2)
        p.setPen(idx_col)
        p.drawText(QRectF(self.width() - 40, 20, 30, 18),
                   Qt.AlignRight | Qt.AlignVCenter, self.data["index"])

        pen = QPen(QColor(LINE))
        pen.setWidthF(1)
        p.setPen(pen)
        p.drawLine(QPointF(0, h - 0.5), QPointF(self.width(), h - 0.5))
        p.end()

    def _draw_wave(self, p, x0, x1, mid):
        """Flat line with one ECG spike — marks PULSE as the louder profile."""
        span = x1 - x0
        if span < 70:
            return
        pen = QPen(QColor(TEXT if self.selected else TEXT_FAINT))
        pen.setWidthF(1.3)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)

        amp = 11.0
        prev = QPointF(x0, mid)
        steps = max(40, int(span))
        for i in range(1, steps + 1):
            t = i / steps
            if 0.44 < t < 0.62:
                k = (t - 0.44) / 0.18
                y = mid - math.sin(k * math.pi * 2) * amp
            else:
                y = mid
            cur = QPointF(x0 + span * t, y)
            p.drawLine(prev, cur)
            prev = cur


class ActionButton(QPushButton):
    """Clipped bottom-right corner, with a title and a subtitle."""

    def __init__(self, title: str, sub: str, glyph: str = "", primary=True, parent=None):
        super().__init__(parent)
        self.title = title
        self.sub = sub
        self.glyph = glyph
        self.primary = primary
        self.setFixedHeight(66 if primary else 58)
        self.setCursor(Qt.PointingHandCursor)
        self._hover = False

    def enterEvent(self, e):
        self._hover = True
        self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self.update()
        super().leaveEvent(e)

    def set_text(self, title=None, sub=None):
        if title is not None:
            self.title = title
        if sub is not None:
            self.sub = sub
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cut = 14

        poly = QPolygonF([
            QPointF(0, 0), QPointF(w - cut, 0), QPointF(w, cut),
            QPointF(w, h), QPointF(cut, h), QPointF(0, h - cut),
        ])
        path = QPainterPath()
        path.addPolygon(poly)
        path.closeSubpath()

        if self.primary:
            bg = QColor(255, 255, 255, 26 if self._hover else 16)
            border = QColor(255, 255, 255, 190 if self._hover else 130)
            tcol = QColor(TEXT)
        else:
            bg = QColor(255, 255, 255, 14 if self._hover else 6)
            border = QColor(255, 255, 255, 110 if self._hover else 55)
            tcol = QColor(TEXT if self._hover else TEXT_DIM)

        p.fillPath(path, bg)
        pen = QPen(border)
        pen.setWidthF(1.2)
        p.setPen(pen)
        p.drawPath(path)

        x = 26
        if self.glyph:
            fg = QFont("Rajdhani", 17)
            p.setFont(fg)
            p.setPen(tcol)
            p.drawText(QRectF(18, 0, 36, h), Qt.AlignCenter, self.glyph)
            x = 64

        ft = QFont("Rajdhani", 16 if self.primary else 14)
        ft.setWeight(QFont.Bold)
        ft.setLetterSpacing(QFont.AbsoluteSpacing, 3.5)
        p.setFont(ft)
        p.setPen(tcol)
        p.drawText(QPointF(x, h / 2 + (0 if not self.sub else -3)), self.title)

        if self.sub:
            fs = QFont("Noto Sans Thai", 8)
            fs.setLetterSpacing(QFont.AbsoluteSpacing, 1.6)
            p.setFont(fs)
            p.setPen(QColor(TEXT_FAINT))
            p.drawText(QPointF(x + 1, h / 2 + 15), self.sub)
        p.end()


class Dot(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(6, 6)
        self.color = QColor(TEXT_FAINT)

    def set_color(self, c: str):
        self.color = QColor(c)
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(self.color)
        p.drawEllipse(0, 0, 6, 6)
        p.end()
