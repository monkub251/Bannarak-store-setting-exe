"""
Painted black hole — accretion disk, photon ring, lensed arc, leader labels.

Pure QPainter, no assets, no blur effects (those cost a repaint of the whole
widget tree). The wispy look comes from many thin elliptical strokes at low
alpha rather than a few fat gradient fills — fat strokes read as a grey donut.
"""

from __future__ import annotations

import math
import random

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget


class BlackHole(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)
        self._phase = 0.0
        rng = random.Random(7)
        self._stars = [
            (rng.random(), rng.random(), rng.random() * 0.45 + 0.08)
            for _ in range(190)
        ]
        # disk strands: (x-scale, y-scale, alpha, drift speed)
        self._strands = []
        for i in range(34):
            t = i / 33.0
            sx = 1.22 + t * 2.35
            sy = 0.055 + (t ** 1.9) * 0.46
            a = int(16 + 96 * math.exp(-((t - 0.22) ** 2) / 0.05))
            self._strands.append((sx, sy, a, 0.6 + t * 1.6))

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(50)

    def _tick(self):
        self._phase = (self._phase + 0.0022) % 1.0
        self.update()

    # ------------------------------------------------------------------
    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor("#060607"))

        cx, cy = w * 0.5, h * 0.5
        R = min(w, h) * 0.195  # event-horizon radius

        self._stars_layer(p, w, h)
        self._disk(p, cx, cy, R, back=True)
        self._lensed_arc(p, cx, cy, R)
        self._shadow(p, cx, cy, R)
        self._photon_ring(p, cx, cy, R)
        self._disk(p, cx, cy, R, back=False)
        self._beam(p, cx, cy, R, w)
        self._labels(p, cx, cy, R)
        p.end()

    # ------------------------------------------------------------------
    def _stars_layer(self, p, w, h):
        for sx, sy, a in self._stars:
            x, y = sx * w, sy * h
            tw = 0.6 + 0.4 * math.sin(self._phase * 6.283 + sx * 11.0)
            p.fillRect(QRectF(x, y, 1.1, 1.1),
                       QColor(255, 255, 255, max(0, int(255 * a * tw))))

    def _disk(self, p, cx, cy, R, back: bool):
        """Thin striated accretion disk. back = behind the shadow."""
        p.save()
        clip = QPainterPath()
        if back:
            clip.addRect(QRectF(cx - R * 5, cy - R * 3.2, R * 10, R * 3.2))
        else:
            clip.addRect(QRectF(cx - R * 5, cy, R * 10, R * 3.2))
        p.setClipPath(clip)
        p.setBrush(Qt.NoBrush)

        for sx, sy, a, spd in self._strands:
            rect = QRectF(cx - R * sx, cy - R * sy, R * sx * 2, R * sy * 2)
            # brightness sweeps around the ring — Doppler-ish shimmer
            k = 0.62 + 0.38 * math.sin(self._phase * 6.283 * spd + sx * 2.1)
            pen = QPen(QColor(255, 255, 255, max(0, min(255, int(a * k)))))
            pen.setWidthF(1.15)
            p.setPen(pen)
            p.drawEllipse(rect)
        p.restore()

    def _lensed_arc(self, p, cx, cy, R):
        """Far side of the disk, lensed up and over the top of the hole."""
        for mult, width, alpha in (
            (1.30, R * 0.085, 14),
            (1.30, R * 0.034, 40),
            (1.30, 1.6, 170),
            (1.42, 1.1, 70),
            (1.19, 1.1, 70),
        ):
            pen = QPen(QColor(255, 255, 255, alpha))
            pen.setWidthF(width)
            pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            rect = QRectF(cx - R * mult, cy - R * mult, R * mult * 2, R * mult * 2)
            p.drawArc(rect, 18 * 16, 144 * 16)

    def _shadow(self, p, cx, cy, R):
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(0, 0, 0))
        p.drawEllipse(QPointF(cx, cy), R, R)

    def _photon_ring(self, p, cx, cy, R):
        for width, alpha in ((R * 0.11, 12), (R * 0.045, 32), (1.5, 225)):
            pen = QPen(QColor(255, 255, 255, alpha))
            pen.setWidthF(width)
            p.setPen(pen)
            p.setBrush(Qt.NoBrush)
            p.drawEllipse(QPointF(cx, cy), R, R)

    def _beam(self, p, cx, cy, R, w):
        """The hard horizontal light streak through the middle."""
        for hw, alpha in ((R * 0.070, 22), (R * 0.022, 70), (1.1, 235)):
            rect = QRectF(cx - w * 0.52, cy - hw, w * 1.04, hw * 2)
            g = QLinearGradient(rect.left(), 0, rect.right(), 0)
            g.setColorAt(0.00, QColor(255, 255, 255, 0))
            g.setColorAt(0.18, QColor(255, 255, 255, int(alpha * 0.35)))
            g.setColorAt(0.50, QColor(255, 255, 255, alpha))
            g.setColorAt(0.82, QColor(255, 255, 255, int(alpha * 0.35)))
            g.setColorAt(1.00, QColor(255, 255, 255, 0))
            p.setPen(Qt.NoPen)
            p.setBrush(g)
            p.drawRect(rect)

    def _labels(self, p, cx, cy, R):
        f = QFont("Rajdhani", 8)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 2.2)
        f.setWeight(QFont.Medium)
        p.setFont(f)

        for text, x, y in (
            ("SHADOW · 5.2 M", cx - R * 2.60, cy - R * 1.78),
            ("PHOTON RING", cx - R * 2.80, cy + R * 1.70),
        ):
            p.setPen(QColor(255, 255, 255, 160))
            p.drawText(QPointF(x, y), text)
            pen = QPen(QColor(255, 255, 255, 80))
            pen.setWidthF(1.0)
            p.setPen(pen)
            p.drawLine(QPointF(x, y + 7), QPointF(x + 92, y + 7))
