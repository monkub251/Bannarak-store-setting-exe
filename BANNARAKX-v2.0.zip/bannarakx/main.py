"""
BANNARAKX — FIVE M · FPS OPTIMIZER  v2.0

Two profiles, one button, one reset.
Run:   python main.py
Build: build.bat
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QObject, QPoint, Qt, QThread, Signal
from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from core.backup import LOG_DIR, Backup
from core.engine import Ctx, global_reset, is_admin, relaunch_as_admin
from core.profiles import PROFILES, RISK_NOTICE
from ui.blackhole import BlackHole
from ui.theme import ACCENT, LINE, QSS, TEXT, TEXT_DIM, TEXT_FAINT
from ui.widgets import ActionButton, Dot, ProfileCard

APP_DIR = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
ASSETS = APP_DIR / "assets"
VERSION = "v2.0"


# ===========================================================================
# worker
# ===========================================================================


class Worker(QObject):
    line = Signal(str, str)
    progress = Signal(int, int, str)
    done = Signal(dict)

    def __init__(self, mode: str, key: str = ""):
        super().__init__()
        self.mode = mode
        self.key = key

    def run(self):
        if self.mode == "optimize":
            self._optimize()
        else:
            self._reset()

    def _optimize(self):
        profile = PROFILES[self.key]
        steps = profile["steps"]
        backup = Backup(profile["name"])
        ctx = Ctx(backup=backup, log=lambda m, l="info": self.line.emit(m, l))

        logfile = LOG_DIR / f"run-{backup.stamp}.log"

        def log(msg, level="info"):
            self.line.emit(msg, level)
            try:
                with logfile.open("a", encoding="utf-8") as fh:
                    fh.write(f"[{level}] {msg}\n")
            except OSError:
                pass

        ctx.log = log
        log(f"=== {profile['name']} ===", "head")

        total = len(steps)
        for i, (label, fn) in enumerate(steps, 1):
            self.progress.emit(i, total, label)
            log(f"--- {label}", "head")
            try:
                fn(ctx)
            except Exception as e:  # noqa: BLE001
                ctx.failed += 1
                log(f"step failed :: {e}", "fail")

        path = backup.save()
        log(f"snapshot saved: {path}", "ok")
        self.done.emit(
            {
                "applied": ctx.applied,
                "failed": ctx.failed,
                "skipped": ctx.skipped,
                "snapshot": str(path),
            }
        )

    def _reset(self):
        snap = Backup.newest()
        if not snap:
            self.line.emit("no snapshot found — nothing to reset", "fail")
            self.done.emit({"applied": 0, "failed": 0, "skipped": 0})
            return
        self.progress.emit(1, 1, "GLOBAL RESET")
        stats = global_reset(snap, lambda m, l="info": self.line.emit(m, l))
        self.done.emit({"applied": stats["ok"], "failed": stats["fail"], "skipped": 0})


# ===========================================================================
# risk dialog
# ===========================================================================


class RiskDialog(QDialog):
    def __init__(self, key: str, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Dialog)
        self.setModal(True)
        self.setFixedWidth(560)

        v = QVBoxLayout(self)
        v.setContentsMargins(34, 30, 34, 26)
        v.setSpacing(14)

        t = QLabel("BEFORE YOU RUN")
        f = QFont("Rajdhani", 17)
        f.setWeight(QFont.Bold)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 4)
        t.setFont(f)
        v.addWidget(t)

        sub = QLabel(
            f"{PROFILES[key]['name']} ลดความปลอดภัยของเครื่องในจุดต่อไปนี้ "
            "ทุกข้อย้อนกลับได้ด้วย GLOBAL RESET"
        )
        sub.setWordWrap(True)
        sub.setProperty("role", "blurb")
        v.addWidget(sub)

        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet(f"background:{LINE};")
        v.addWidget(line)

        for title, why in RISK_NOTICE[key]:
            h = QLabel(f"— {title}")
            hf = QFont("Rajdhani", 11)
            hf.setWeight(QFont.DemiBold)
            h.setFont(hf)
            h.setStyleSheet(f"color:{TEXT};")
            h.setWordWrap(True)
            v.addWidget(h)

            d = QLabel(why)
            d.setWordWrap(True)
            d.setStyleSheet(f"color:{TEXT_FAINT}; font-size:11px;")
            d.setContentsMargins(14, 0, 0, 4)
            v.addWidget(d)

        v.addSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(12)
        cancel = ActionButton("CANCEL", "", primary=False)
        cancel.setFixedWidth(150)
        go = ActionButton("I UNDERSTAND · RUN", "", primary=True)
        cancel.clicked.connect(self.reject)
        go.clicked.connect(self.accept)
        row.addWidget(cancel)
        row.addWidget(go, 1)
        v.addLayout(row)


# ===========================================================================
# main window
# ===========================================================================


class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setObjectName("root")
        self.resize(1280, 808)
        self.setMinimumSize(1120, 720)

        self.current = "PULSE"
        self.busy = False
        self._drag = None
        self.thread = None
        self.worker = None

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        outer.addWidget(self._build_topbar())
        self.stack = QStackedWidget()
        outer.addWidget(self.stack, 1)
        outer.addWidget(self._build_bottombar())

        self.page_home = self._build_home()
        self.page_gif = self._build_simple(
            "GIF HUB", "ยังไม่ได้ต่อ — บอกมาว่าหน้านี้ควรทำอะไร เดี๋ยวใส่ให้"
        )
        self.page_log = self._build_log()
        self.page_about = self._build_about()
        for p in (self.page_home, self.page_gif, self.page_log, self.page_about):
            self.stack.addWidget(p)

        self._select("PULSE")
        self._nav_to(0)

    # -- top bar -------------------------------------------------------
    def _build_topbar(self):
        bar = QWidget()
        bar.setFixedHeight(78)
        h = QHBoxLayout(bar)
        h.setContentsMargins(26, 0, 20, 0)
        h.setSpacing(0)

        logo = QLabel()
        logo.setFixedSize(46, 46)
        pm = ASSETS / "logo.png"
        if pm.exists():
            logo.setPixmap(
                QPixmap(str(pm)).scaled(46, 46, Qt.KeepAspectRatio,
                                        Qt.SmoothTransformation)
            )
        else:
            logo.setPixmap(self._fallback_mark())
        h.addWidget(logo)
        h.addSpacing(16)

        name = QVBoxLayout()
        name.setSpacing(2)
        b = QLabel("BANNARAKX")
        b.setProperty("role", "brand")
        s = QLabel("FIVE M · FPS OPTIMIZER")
        s.setProperty("role", "brandsub")
        name.addWidget(b)
        name.addWidget(s)
        h.addLayout(name)
        h.addStretch(1)

        self.navs = []
        for i, label in enumerate(("HOME", "GIF HUB", "LOG", "ABOUT")):
            btn = QPushButton(label)
            btn.setProperty("role", "nav")
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, n=i: self._nav_to(n))
            h.addWidget(btn)
            h.addSpacing(26)
            self.navs.append(btn)

        h.addSpacing(10)
        for glyph, role, fn in (
            ("\u2014", "win", self.showMinimized),
            ("\u25a1", "win", self._toggle_max),
            ("\u2715", "close", self.close),
        ):
            b2 = QPushButton(glyph)
            b2.setProperty("role", role)
            b2.setFixedSize(34, 34)
            b2.setCursor(Qt.PointingHandCursor)
            b2.clicked.connect(fn)
            h.addWidget(b2)
        return bar

    def _fallback_mark(self):
        pm = QPixmap(46, 46)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(QColor(TEXT))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(7, 7, 32, 32)
        p.drawLine(2, 23, 44, 23)
        p.end()
        return pm

    def _toggle_max(self):
        self.showNormal() if self.isMaximized() else self.showMaximized()

    # -- home ----------------------------------------------------------
    def _build_home(self):
        page = QWidget()
        h = QHBoxLayout(page)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)

        self.bh = BlackHole()
        self.bh.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        h.addWidget(self.bh, 1)

        panel = QWidget()
        panel.setFixedWidth(452)
        v = QVBoxLayout(panel)
        v.setContentsMargins(22, 56, 56, 40)
        v.setSpacing(0)

        lab = QLabel("SELECT PROFILE")
        lab.setProperty("role", "sectionlabel")
        v.addWidget(lab)
        v.addSpacing(22)

        self.cards = {}
        for key in ("ULTIMATE", "PULSE"):
            card = ProfileCard(key, PROFILES[key])
            card.clicked.connect(self._select)
            v.addWidget(card)
            self.cards[key] = card

        v.addSpacing(22)
        self.blurb = QLabel()
        self.blurb.setWordWrap(True)
        self.blurb.setProperty("role", "blurb")
        v.addWidget(self.blurb)
        v.addSpacing(14)

        self.bullets = QVBoxLayout()
        self.bullets.setSpacing(7)
        v.addLayout(self.bullets)

        v.addStretch(1)

        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(2)
        self.bar.setVisible(False)
        v.addWidget(self.bar)
        v.addSpacing(14)

        self.btn_go = ActionButton("OPTIMIZE", "PULSE V2 · HIGH IMPACT", "\u2713")
        self.btn_go.clicked.connect(self._on_optimize)
        v.addWidget(self.btn_go)
        v.addSpacing(12)

        self.btn_reset = ActionButton(
            "GLOBAL RESET", "คืนค่าที่แอปปรับไว้เป็นค่าเดิม", "\u21ba", primary=False
        )
        self.btn_reset.clicked.connect(self._on_reset)
        v.addWidget(self.btn_reset)

        h.addWidget(panel)
        return page

    # -- other pages ---------------------------------------------------
    def _build_simple(self, title, body):
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(64, 54, 64, 54)
        t = QLabel(title)
        f = QFont("Rajdhani", 22)
        f.setWeight(QFont.Bold)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 5)
        t.setFont(f)
        v.addWidget(t)
        v.addSpacing(10)
        b = QLabel(body)
        b.setProperty("role", "blurb")
        b.setWordWrap(True)
        v.addWidget(b)
        v.addStretch(1)
        return page

    def _build_log(self):
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(64, 46, 64, 40)
        v.setSpacing(14)

        t = QLabel("LOG")
        f = QFont("Rajdhani", 22)
        f.setWeight(QFont.Bold)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 5)
        t.setFont(f)
        v.addWidget(t)

        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(6000)
        v.addWidget(self.console, 1)

        row = QHBoxLayout()
        p = QLabel(f"saved to  {LOG_DIR}")
        p.setStyleSheet(f"color:{TEXT_FAINT}; font-size:10px;")
        row.addWidget(p)
        row.addStretch(1)
        clear = QPushButton("CLEAR")
        clear.setProperty("role", "nav")
        clear.setCursor(Qt.PointingHandCursor)
        clear.clicked.connect(self.console.clear)
        row.addWidget(clear)
        v.addLayout(row)
        return page

    def _build_about(self):
        body = (
            "BANNARAKX FIVE M · FPS OPTIMIZER " + VERSION + "\n\n"
            "ทุกค่าที่แอปเขียน จะบันทึกค่าเดิมลง snapshot ก่อนเสมอ "
            "GLOBAL RESET อ่าน snapshot ล่าสุดแล้วคืนค่าทีละตัว "
            "ค่าไหนเดิมไม่มี มันลบทิ้ง ไม่ใช่เดาค่า default\n\n"
            "snapshot: %PROGRAMDATA%\\BANNARAKX\\backups\n"
            "log:      %PROGRAMDATA%\\BANNARAKX\\logs\n\n"
            "สิ่งที่แอปทำแทนไม่ได้ ต้องทำมือ เรียงตามผลจริง:\n"
            "  1. เปิด XMP / EXPO ใน BIOS — ได้ FPS มากกว่าทุกอย่างในแอปรวมกัน\n"
            "  2. ใช้สาย LAN — jitter ของ Wi-Fi กินทุก network tweak ในนี้\n"
            "  3. ตั้ง FPS cap = refresh rate ลบ 3 + Low Latency Mode Ultra\n"
            "  4. G-Sync/FreeSync เปิด · VSync ในเกมปิด\n"
            "  5. Population Density + Distance Scaling ลดเหลือ 0–30%\n"
        )
        return self._build_simple("ABOUT", body)

    # -- bottom bar ----------------------------------------------------
    def _build_bottombar(self):
        bar = QWidget()
        bar.setFixedHeight(44)
        h = QHBoxLayout(bar)
        h.setContentsMargins(30, 0, 30, 0)
        h.setSpacing(12)

        self.dot = Dot()
        h.addWidget(self.dot)
        lab = QLabel("STATUS")
        lab.setProperty("role", "status")
        h.addWidget(lab)
        h.addSpacing(8)
        self.status = QLabel("READY")
        self.status.setProperty("role", "statusval")
        h.addWidget(self.status)
        h.addStretch(1)

        v = QLabel(f"BANNARAKX · {VERSION}")
        v.setProperty("role", "status")
        h.addWidget(v)
        return bar

    # -- behaviour -----------------------------------------------------
    def _nav_to(self, idx):
        self.stack.setCurrentIndex(idx)
        for i, b in enumerate(self.navs):
            b.setProperty("active", "true" if i == idx else "false")
            b.style().unpolish(b)
            b.style().polish(b)

    def _select(self, key):
        if self.busy:
            return
        self.current = key
        d = PROFILES[key]
        for k, c in self.cards.items():
            c.set_selected(k == key)

        self.blurb.setText(d["blurb"])
        while self.bullets.count():
            item = self.bullets.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for b in d["bullets"]:
            lab = QLabel(f"—   {b}")
            lab.setProperty("role", "bullet")
            lab.setWordWrap(True)
            self.bullets.addWidget(lab)

        self.btn_go.set_text(sub=f"{d['name']} · {d['impact']}")

    def _set_status(self, text, color=TEXT_FAINT):
        self.status.setText(text)
        self.dot.set_color(color)

    def _append(self, msg, level):
        colors = {
            "ok": TEXT_DIM, "fail": "#FF6B6B", "warn": "#E0C060",
            "head": TEXT, "skip": "#3C3C42", "info": TEXT_FAINT,
        }
        c = colors.get(level, TEXT_DIM)
        self.console.appendHtml(
            f'<span style="color:{c}">{msg}</span>'
        )

    # -- run -----------------------------------------------------------
    def _on_optimize(self):
        if self.busy:
            return
        dlg = RiskDialog(self.current, self)
        if dlg.exec() != QDialog.Accepted:
            self._set_status("CANCELLED")
            return
        self._start("optimize", self.current)

    def _on_reset(self):
        if self.busy:
            return
        snap = Backup.newest()
        if not snap:
            self._set_status("NO SNAPSHOT", "#E0C060")
            self._append("no snapshot found — nothing to reset", "fail")
            self._nav_to(2)
            return
        self._start("reset")

    def _start(self, mode, key=""):
        self.busy = True
        self.bar.setVisible(True)
        self.bar.setRange(0, 0)
        self._set_status("RUNNING", ACCENT)
        self._nav_to(2)
        self.console.clear()

        self.thread = QThread()
        self.worker = Worker(mode, key)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.line.connect(self._append)
        self.worker.progress.connect(self._on_progress)
        self.worker.done.connect(self._on_done)
        self.thread.start()

    def _on_progress(self, i, total, label):
        self.bar.setRange(0, total)
        self.bar.setValue(i)
        self._set_status(f"{i}/{total}  {label.upper()}", ACCENT)

    def _on_done(self, stats):
        self.busy = False
        self.bar.setVisible(False)
        if self.thread:
            self.thread.quit()
            self.thread.wait(3000)
        ok, fail = stats.get("applied", 0), stats.get("failed", 0)
        self._set_status(
            f"DONE · {ok} APPLIED · {fail} FAILED · REBOOT REQUIRED",
            "#7BE08A" if fail == 0 else "#E0C060",
        )
        self._append("", "info")
        self._append("reboot to finish — power, NIC and kernel changes need it", "head")

    # -- frameless drag -------------------------------------------------
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton and e.position().y() < 78:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag and e.buttons() & Qt.LeftButton and not self.isMaximized():
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, _e):
        self._drag = None

    def closeEvent(self, e):
        if self.busy:
            e.ignore()
            return
        if self.thread and self.thread.isRunning():
            self.thread.quit()
            self.thread.wait(2000)
        e.accept()


# ===========================================================================
def main():
    if sys.platform != "win32":
        print("Windows only.")
        return 1
    if not is_admin():
        if relaunch_as_admin():
            return 0

    app = QApplication(sys.argv)
    app.setStyleSheet(QSS)
    ico = ASSETS / "logo.png"
    if ico.exists():
        app.setWindowIcon(QIcon(str(ico)))

    w = Window()
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
