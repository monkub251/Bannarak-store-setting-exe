# BANNARAKX — FIVE M · FPS OPTIMIZER v2.0

แอป Windows หน้าเดียว ปุ่มเดียว สองโปรไฟล์ กับปุ่มคืนค่า

---

## รันจากซอร์ส

```bat
pip install -r requirements.txt
python main.py
```

แอปจะขอสิทธิ์ Administrator เอง ไม่ต้องคลิกขวา — ทุก tweak เขียน HKLM หรือสั่ง service

## Build เป็น .exe

```bat
build.bat
```

ได้ `dist\BANNARAKX.exe` ไฟล์เดียว ไม่มีหน้าต่าง console ขอ UAC ตอนเปิด

ไฟล์ประมาณ 40–55 MB เพราะ PySide6 ติดมาทั้งชุด — `BANNARAKX.spec` ตัดโมดูลที่ไม่ใช้ออกแล้ว (WebEngine, Quick, Multimedia, Charts, SQL ฯลฯ) ถ้าไม่ตัดจะ ~90 MB

**Antivirus**: exe ที่ build ด้วย PyInstaller + UPX + ขอ UAC โดน heuristic ของ Defender/SmartScreen บ่อย ถ้าโดน ให้ใส่ exclusion ที่โฟลเดอร์ `dist` หรือเอา `upx=True` ออกจาก spec

---

## สองโปรไฟล์

| | ULTIMATE V2 | PULSE V2 |
|---|---|---|
| ขั้นตอน | 14 | 18 |
| ทิศทาง | FPS สูงสุด เฟรมนิ่ง | ทุกอย่างของ ULTIMATE + บีบ latency |
| เพิ่มมาจาก ULTIMATE | — | หยุดงานเบื้องหลัง · latency pass · QoS DSCP 46 · ลดโปรเซส |

PULSE เป็น superset ของ ULTIMATE แบบตรงตัว — step ทั้ง 14 ตัวแรกคือชุดเดียวกัน

---

## Backup / GLOBAL RESET

ทุกค่าที่เขียน บันทึกค่าเดิมลง snapshot JSON **ก่อน** เขียนเสมอ

```
%PROGRAMDATA%\BANNARAKX\backups\backup-YYYYMMDD-HHMMSS.json
%PROGRAMDATA%\BANNARAKX\logs\run-YYYYMMDD-HHMMSS.log
```

GLOBAL RESET อ่าน snapshot ล่าสุดแล้วคืนค่าทีละตัว **ย้อนลำดับ**:

- ค่าเดิมมีอยู่ → เขียนค่าเดิมกลับ
- ค่าเดิมไม่มี แต่ key มี → ลบเฉพาะค่านั้น
- key เพิ่งถูกสร้าง → ลบทั้ง key

ย้อนลำดับเพราะหลายค่าลงใน key ที่เพิ่งสร้างอันเดียวกัน (เช่น QoS 11 ค่า) ถ้าไล่หน้าไปหลัง entry แรกจะลบ key ทิ้งก่อนที่ entry ที่เหลือจะได้ทำงาน

คืนค่า service, power scheme, TCP autotuning, NIC properties, memory compression, fsutil last-access และ DNS กลับเป็น DHCP ด้วย

---

## โครงไฟล์

```
main.py              หน้าต่าง, worker thread, risk dialog
core/backup.py       snapshot store
core/engine.py       registry / service / task / powercfg primitives + GLOBAL RESET
core/profiles.py     นิยาม step ทั้งหมด + ข้อความเตือน
ui/theme.py          สี, ฟอนต์, QSS
ui/blackhole.py      ภาพหลุมดำ (QPainter ล้วน ไม่มีไฟล์ asset)
ui/widgets.py        profile card, action button, status dot
assets/logo.png      โลโก้
```

---

## สิ่งที่แอปทำแทนไม่ได้ เรียงตามผลจริง

1. **เปิด XMP / EXPO ใน BIOS** — RAM หลายเครื่องวิ่ง 2133 MHz ทั้งที่ซื้อมา 3600 ข้อนี้ได้ FPS มากกว่าทุกอย่างในแอปรวมกัน
2. **ใช้สาย LAN** — jitter ของ Wi-Fi กินทุก network tweak ในนี้
3. **FPS cap = refresh rate ลบ 3** + Low Latency Mode Ultra ใน NVIDIA Control Panel
4. **G-Sync/FreeSync เปิด · VSync ในไดรเวอร์เปิด · VSync ในเกมปิด**
5. **Population Density + Distance Scaling เหลือ 0–30%** — CPU win ที่ใหญ่สุดในเซิร์ฟคนเยอะ

---

## ข้อควรรู้ก่อนกด

ทั้งสองโปรไฟล์ลดความปลอดภัยของเครื่องจริง แอปขึ้น dialog บอกก่อนทุกครั้ง อ่านให้จบก่อนกด I UNDERSTAND

- **Memory Integrity (HVCI) off** — driver ไม่ผ่านการตรวจด้วย hypervisor อีก ได้ 2–6% เฉพาะตอน CPU-bound
- **Spectre/Meltdown mitigations off** — บน Zen 3+ หรือ Intel 10th gen ขึ้นไป **ได้เกือบศูนย์** เพราะ CPU แก้ที่ hardware แล้ว
- **Memory compression off** (PULSE) — RAM 16GB หรือน้อยกว่า อันนี้ทำให้ **กระตุกหนักกว่าเดิม**
- **Windows Update paused 35 วัน** (PULSE) — ไม่มี security patch จนกว่าจะครบ แล้วมันกลับมาเอง
- **File sharing / RDP / printing ปิด** (PULSE) — เครื่องพิมพ์กับโฟลเดอร์แชร์หยุดทำงาน

ทุกข้อย้อนกลับได้ด้วย GLOBAL RESET แล้วรีบูต
