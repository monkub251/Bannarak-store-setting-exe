@echo off
REM ===========================================================================
REM  BANNARAKX FIVE M - FPS OPTIMIZER  ::  build to a single .exe
REM  Run this on Windows with Python 3.10+ installed.
REM ===========================================================================
setlocal

echo.
echo   BANNARAKX - build
echo   -----------------
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo   [X] Python not found on PATH.
    echo       Install Python 3.10+ and tick "Add python.exe to PATH".
    pause
    exit /b 1
)

echo   [1/4] installing dependencies...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
    echo   [X] pip install failed.
    pause
    exit /b 1
)

echo   [2/4] cleaning old build...
if exist build rmdir /s /q build
if exist dist  rmdir /s /q dist

echo   [3/4] building...
python -m PyInstaller BANNARAKX.spec --noconfirm
if errorlevel 1 (
    echo   [X] build failed - see the output above.
    pause
    exit /b 1
)

echo   [4/4] done.
echo.
echo   Output:  dist\BANNARAKX.exe
echo.
echo   Note: the exe asks for Administrator when launched - it has to,
echo   every tweak writes to HKLM or controls a service.
echo.
pause
